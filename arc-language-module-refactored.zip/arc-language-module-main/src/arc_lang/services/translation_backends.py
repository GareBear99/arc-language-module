"""
arc_lang.services.translation_backends
=======================================
Thin re-export shim — implementation now lives in the per-provider
arc_lang.services.providers package.

Every name that external code imports from this module is still importable
here with zero changes to callers (routes, orchestration, diagnostics, CLI,
and the existing test suite).
"""
from arc_lang.services.providers import (          # noqa: F401  (re-exports)
    ISO6393_TO_RUNTIME,
    TranslationBackend,
    _language_codes,
    _argostranslate_available,
    LocalSeedTranslationBackend,
    MirrorTranslationBackend,
    ArgosLocalTranslationBackend,
    BoundaryStubTranslationBackend,
    BUILTIN_TRANSLATION_BACKENDS,
    get_translation_backend,
    list_builtin_translation_backends,
)

__all__ = [
    'ISO6393_TO_RUNTIME',
    'TranslationBackend',
    '_language_codes',
    '_argostranslate_available',
    'LocalSeedTranslationBackend',
    'MirrorTranslationBackend',
    'ArgosLocalTranslationBackend',
    'BoundaryStubTranslationBackend',
    'BUILTIN_TRANSLATION_BACKENDS',
    'get_translation_backend',
    'list_builtin_translation_backends',
]
