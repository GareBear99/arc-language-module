from __future__ import annotations

from arc_lang.core.models import RuntimeTranslateRequest
from arc_lang.services.providers.base import TranslationBackend


class MirrorTranslationBackend(TranslationBackend):
    name = 'mirror_mock'

    def translate(self, req: RuntimeTranslateRequest, source_language_id: str) -> dict:
        """Echo the input unchanged — only valid when source and target language are the same."""
        if source_language_id != req.target_language_id:
            return {
                'ok': False,
                'provider': self.name,
                'error': 'mirror_requires_same_language',
                'notes': ['mirror_mock only supports same-language echo/mirror behavior.'],
            }
        return {
            'ok': True,
            'mode': 'backend_mirror_mock',
            'provider': self.name,
            'translation': {
                'ok': True,
                'mode': 'mirror_same_language',
                'source_language_id': source_language_id,
                'target_language_id': req.target_language_id,
                'source_text': req.text,
                'translated_text': req.text,
                'register': 'identity',
                'provenance': [],
                'rationale': 'Mirror backend returned same-language identity output.',
            },
            'notes': ['Useful for dry pipeline verification and same-language normalization tests.'],
        }
