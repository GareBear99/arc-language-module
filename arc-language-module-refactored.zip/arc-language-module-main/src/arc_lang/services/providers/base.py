from __future__ import annotations

import importlib.util
from arc_lang.core.db import connect
from arc_lang.core.models import RuntimeTranslateRequest

ISO6393_TO_RUNTIME = {
    # Major world languages
    'eng': 'en', 'spa': 'es', 'fra': 'fr', 'deu': 'de', 'ita': 'it', 'por': 'pt',
    'rus': 'ru', 'ukr': 'uk', 'jpn': 'ja', 'kor': 'ko',
    'hin': 'hi', 'ben': 'bn', 'mar': 'mr', 'urd': 'ur', 'tam': 'ta', 'tel': 'te',
    'pan': 'pa', 'heb': 'he', 'tha': 'th', 'nld': 'nl', 'pol': 'pl', 'tur': 'tr',
    'vie': 'vi', 'ind': 'id',
    # Seeded language-specific ISO codes
    'arb': 'ar',   # Arabic (Modern Standard) — iso arb, runtime code ar
    'cmn': 'zh',   # Mandarin Chinese — iso cmn, runtime code zh
    'yue': 'yue',  # Cantonese — iso yue, runtime code yue (limited Argos support)
    'fas': 'fa',   # Persian/Farsi
    'msa': 'ms',   # Malay
    'swa': 'sw',   # Swahili
    'amh': 'am',   # Amharic
    # Low-resource / Indigenous — runtime codes exist but Argos coverage is absent
    'nav': 'nav',  # Navajo — no known Argos package; runtime stub only
    'chr': 'chr',  # Cherokee — no known Argos package; runtime stub only
    'crk': 'crk',  # Plains Cree — no known Argos package; runtime stub only
    'ell': 'el',   # Greek (Modern)
}


def _language_codes(language_id: str) -> dict:
    """Return language code information (language_id, iso639_3, runtime_code, name) for a language."""
    with connect() as conn:
        row = conn.execute(
            "SELECT language_id, iso639_3, name FROM languages WHERE language_id = ?",
            (language_id,),
        ).fetchone()
    if not row:
        return {'language_id': language_id, 'iso639_3': None, 'runtime_code': None, 'name': None}
    iso3 = row['iso639_3']
    return {
        'language_id': row['language_id'],
        'iso639_3': iso3,
        'runtime_code': ISO6393_TO_RUNTIME.get(iso3) or iso3,
        'name': row['name'],
    }


def _argostranslate_available() -> bool:
    """Return True if the argostranslate library is installed."""
    return importlib.util.find_spec('argostranslate') is not None


class TranslationBackend:
    name = 'base'

    def translate(self, req: RuntimeTranslateRequest, source_language_id: str) -> dict:
        """Execute a translation request through this backend adapter and return the result dict."""
        raise NotImplementedError
