from __future__ import annotations

from arc_lang.core.models import RuntimeTranslateRequest, TranslateExplainQuery
from arc_lang.services.translate_explain import translate_explain
from arc_lang.services.providers.base import TranslationBackend


class LocalSeedTranslationBackend(TranslationBackend):
    name = 'local_seed'

    def translate(self, req: RuntimeTranslateRequest, source_language_id: str) -> dict:
        """Resolve translation through the local seeded phrase/lexeme graph."""
        result = translate_explain(TranslateExplainQuery(
            text=req.text,
            source_language_id=source_language_id,
            target_language_id=req.target_language_id,
            allow_detect=False,
        ))
        if result.get('ok'):
            return {
                'ok': True,
                'mode': 'backend_local_seed',
                'provider': self.name,
                'translation': result,
                'notes': ['Resolved by local seeded phrase/lexeme graph.'],
            }
        return {
            'ok': False,
            'provider': self.name,
            'error': result.get('error', 'local_seed_unresolved'),
            'backend_response': result,
            'notes': ['Local seeded graph could not resolve this translation.'],
        }
