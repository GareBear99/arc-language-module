from __future__ import annotations

from arc_lang.core.models import RuntimeTranslateRequest
from arc_lang.services.providers.base import (
    TranslationBackend, _argostranslate_available, _language_codes,
)


class ArgosLocalTranslationBackend(TranslationBackend):
    name = 'argos_local'

    def translate(self, req: RuntimeTranslateRequest, source_language_id: str) -> dict:
        """Translate via the optional local Argos Translate installation."""
        if not _argostranslate_available():
            return {
                'ok': False,
                'provider': self.name,
                'error': 'translation_backend_dependency_missing',
                'dependency': 'argostranslate',
                'notes': ['Install argostranslate plus matching language packages to enable local execution.'],
            }
        src = _language_codes(source_language_id)
        dst = _language_codes(req.target_language_id)
        if not src['runtime_code'] or not dst['runtime_code']:
            return {
                'ok': False,
                'provider': self.name,
                'error': 'translation_backend_language_code_unmapped',
                'source_language': src,
                'target_language': dst,
                'notes': ['No runtime mapping exists from internal language ID to Argos language code.'],
            }
        try:
            from argostranslate import translate as argos_translate
            installed = argos_translate.get_installed_languages()
        except Exception as e:
            return {
                'ok': False,
                'provider': self.name,
                'error': 'translation_backend_dependency_failed',
                'notes': [f'argostranslate import/runtime failed: {type(e).__name__}: {e}'],
            }

        source_lang = next((l for l in installed if getattr(l, 'code', None) == src['runtime_code']), None)
        target_lang = next((l for l in installed if getattr(l, 'code', None) == dst['runtime_code']), None)
        if not source_lang or not target_lang:
            return {
                'ok': False,
                'provider': self.name,
                'error': 'translation_backend_language_pair_missing',
                'source_language': src,
                'target_language': dst,
                'installed_codes': sorted([getattr(l, 'code', None) for l in installed if getattr(l, 'code', None)]),
                'notes': ['Argos runtime is installed, but the requested source/target package pair is not available locally.'],
            }
        try:
            translation_obj = source_lang.get_translation(target_lang)
            if translation_obj is None:
                return {
                    'ok': False,
                    'provider': self.name,
                    'error': 'translation_backend_language_pair_missing',
                    'source_language': src,
                    'target_language': dst,
                    'notes': ['Argos source/target languages are present, but no direct translation package was found.'],
                }
            translated_text = translation_obj.translate(req.text)
        except Exception as e:
            return {
                'ok': False,
                'provider': self.name,
                'error': 'translation_backend_runtime_failed',
                'source_language': src,
                'target_language': dst,
                'notes': [f'Argos runtime translation failed: {type(e).__name__}: {e}'],
            }

        return {
            'ok': True,
            'mode': 'backend_argos_local',
            'provider': self.name,
            'translation': {
                'ok': True,
                'mode': 'argos_local_translate',
                'source_language_id': source_language_id,
                'target_language_id': req.target_language_id,
                'source_text': req.text,
                'translated_text': translated_text,
                'register': 'general',
                'provenance': [
                    {
                        'source_name': 'argostranslate',
                        'source_ref': f"{src['runtime_code']}->{dst['runtime_code']}",
                        'confidence': 0.7,
                        'notes': 'Optional local Argos Translate backend execution.',
                    }
                ],
                'rationale': 'Translated by optional local Argos backend adapter.',
            },
            'dispatch_payload': {
                'source_runtime_code': src['runtime_code'],
                'target_runtime_code': dst['runtime_code'],
                'dry_run': req.dry_run,
            },
            'notes': ['Executed through optional local Argos Translate backend.'],
        }
