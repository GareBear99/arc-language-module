from __future__ import annotations

from arc_lang.core.models import RuntimeTranslateRequest
from arc_lang.services.providers.base import TranslationBackend


class BoundaryStubTranslationBackend(TranslationBackend):
    """Generic boundary stub for providers that are wired but have no live
    runtime bridge configured yet (e.g. argos_bridge, nllb_bridge)."""

    def __init__(self, name: str):
        self.name = name

    def translate(self, req: RuntimeTranslateRequest, source_language_id: str) -> dict:
        """Accept dry-run requests; reject live requests until a bridge adapter is configured."""
        payload = {
            'provider': self.name,
            'source_language_id': source_language_id,
            'target_language_id': req.target_language_id,
            'text': req.text,
            'voice_hint': req.voice_hint,
        }
        if req.dry_run:
            return {
                'ok': True,
                'mode': 'backend_boundary_dry_run',
                'provider': self.name,
                'translation': {
                    'ok': True,
                    'mode': 'boundary_stub',
                    'source_language_id': source_language_id,
                    'target_language_id': req.target_language_id,
                    'source_text': req.text,
                    'translated_text': None,
                    'register': 'unresolved',
                    'provenance': [],
                    'rationale': f'{self.name} boundary accepted the request in dry-run mode.',
                },
                'dispatch_payload': payload,
                'notes': [
                    f'{self.name} is wired as a backend boundary stub.',
                    'Provide a live adapter/runtime bridge to execute actual remote translation.',
                ],
            }
        return {
            'ok': False,
            'provider': self.name,
            'error': 'translation_backend_live_bridge_missing',
            'dispatch_payload': payload,
            'notes': [
                f'{self.name} boundary exists, but no live runtime bridge is configured in this package.',
            ],
        }
