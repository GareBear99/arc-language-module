"""
arc_lang.services.providers
============================
Per-provider translation backend adapters.  Each adapter owns exactly one
provider's logic.  The registry and factory live here so callers can do:

    from arc_lang.services.providers import get_translation_backend
    from arc_lang.services.providers import BUILTIN_TRANSLATION_BACKENDS

without caring which sub-module a specific adapter came from.
"""
from __future__ import annotations

from arc_lang.services.providers.base import (
    ISO6393_TO_RUNTIME,
    TranslationBackend,
    _argostranslate_available,
    _language_codes,
)
from arc_lang.services.providers.local_seed import LocalSeedTranslationBackend
from arc_lang.services.providers.mirror import MirrorTranslationBackend
from arc_lang.services.providers.argos_local import ArgosLocalTranslationBackend
from arc_lang.services.providers.boundary_stub import BoundaryStubTranslationBackend

BUILTIN_TRANSLATION_BACKENDS: dict = {
    'local_seed':   LocalSeedTranslationBackend,
    'mirror_mock':  MirrorTranslationBackend,
    'argos_local':  ArgosLocalTranslationBackend,
    'argos_bridge': lambda: BoundaryStubTranslationBackend('argos_bridge'),
    'nllb_bridge':  lambda: BoundaryStubTranslationBackend('nllb_bridge'),
}


def get_translation_backend(name: str | None) -> TranslationBackend | None:
    """Return a TranslationBackend instance by provider name, or None."""
    if not name:
        return None
    factory = BUILTIN_TRANSLATION_BACKENDS.get(name)
    if not factory:
        return None
    return factory()


def list_builtin_translation_backends() -> dict:
    """List all built-in translation backends with their kind, live_execution
    status, and dependency notes."""
    argos_available = _argostranslate_available()
    return {
        'ok': True,
        'backends': [
            {'provider_name': 'local_seed',   'kind': 'local',          'live_execution': True,            'optional_dependency': None,              'notes': 'Seeded graph-backed phrase/lexeme translation.'},
            {'provider_name': 'mirror_mock',  'kind': 'local',          'live_execution': True,            'optional_dependency': None,              'notes': 'Same-language mirror backend for pipeline validation.'},
            {'provider_name': 'argos_local',  'kind': 'local_optional', 'live_execution': argos_available, 'optional_dependency': 'argostranslate',  'notes': 'Optional offline local Argos Translate adapter when the dependency and language packages are installed.'},
            {'provider_name': 'argos_bridge', 'kind': 'boundary',       'live_execution': False,           'optional_dependency': None,              'notes': 'Boundary stub alias for future/live Argos bridge integration.'},
            {'provider_name': 'nllb_bridge',  'kind': 'boundary',       'live_execution': False,           'optional_dependency': None,              'notes': 'Bridge stub for a future NLLB-style adapter.'},
        ],
    }


__all__ = [
    'ISO6393_TO_RUNTIME',
    'TranslationBackend',
    '_language_codes',
    '_argostranslate_available',
    'LocalSeedTranslationBackend',
    'MirrorTranslationBackend',
    'ArgosLocalTranslationBackend',
    'BoundaryStubTranslationBackend',
    'BUILTIN_TRANSLATION_BACKENDS',
    'get_translation_backend',
    'list_builtin_translation_backends',
]
